## Documentation and examples are available here: [https://www.andreaamico.eu/data-analysis/2018/03/03/fit_wrapper.html](https://www.andreaamico.eu/data-analysis/2018/03/03/fit_wrapper.html)
