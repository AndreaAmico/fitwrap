__author__ = "Andrea Amico (amico.andrea.90@gmail.com)"
__version__ = "0.0.1"
__copyright__ = "Copyright (c) 2018 Andrea Amico"
__license__ = "MIT"

from .fit import fit
from .fit2d import fit2d
from .sine import fit_sin
from .sine import lomb_spectrum
from .gauss import fit_gauss



